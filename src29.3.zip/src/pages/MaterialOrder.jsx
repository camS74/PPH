import React from 'react';
import '../styles/MaterialOrder.css';

function MaterialOrder() {
  return (
    <div className="materialorder-page">
      <h2>MaterialOrder</h2>
      <p>This is the MaterialOrder page. Content will be added later.</p>
    </div>
  );
}

export default MaterialOrder;
