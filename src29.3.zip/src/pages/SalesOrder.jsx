import React from 'react';
import '../styles/SalesOrder.css';

function SalesOrder() {
  return (
    <div className="salesorder-page">
      <h2>SalesOrder</h2>
      <p>This is the SalesOrder page. Content will be added later.</p>
    </div>
  );
}

export default SalesOrder;
