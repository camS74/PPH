import React from 'react';
import '../styles/EstimationForm.css';

function EstimationForm() {
  return (
    <div className="estimationform-page">
      <h2>EstimationForm</h2>
      <p>This is the EstimationForm page. Content will be added later.</p>
    </div>
  );
}

export default EstimationForm;
