import React from 'react';
import '../styles/QuotationForm.css';

function QuotationForm() {
  return (
    <div className="quotationform-page">
      <h2>QuotationForm</h2>
      <p>This is the QuotationForm page. Content will be added later.</p>
    </div>
  );
}

export default QuotationForm;
