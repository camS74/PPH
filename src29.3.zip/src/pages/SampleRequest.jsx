import React from 'react';
import '../styles/SampleRequest.css';

function SampleRequest() {
  return (
    <div className="samplerequest-page">
      <h2>SampleRequest</h2>
      <p>This is the SampleRequest page. Content will be added later.</p>
    </div>
  );
}

export default SampleRequest;
