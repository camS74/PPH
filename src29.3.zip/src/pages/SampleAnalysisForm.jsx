import React from 'react';
import '../styles/SampleAnalysisForm.css';

function SampleAnalysisForm() {
  return (
    <div className="sampleanalysisform-page">
      <h2>SampleAnalysisForm</h2>
      <p>This is the SampleAnalysisForm page. Content will be added later.</p>
    </div>
  );
}

export default SampleAnalysisForm;
