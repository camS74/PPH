import React from 'react';
import '../styles/EstimationRequest.css';

function EstimationRequest() {
  return (
    <div className="estimationrequest-page">
      <h2>EstimationRequest</h2>
      <p>This is the EstimationRequest page. Content will be added later.</p>
    </div>
  );
}

export default EstimationRequest;
