import React from 'react';
import '../styles/JobCard.css';

function JobCard() {
  return (
    <div className="jobcard-page">
      <h2>JobCard</h2>
      <p>This is the JobCard page. Content will be added later.</p>
    </div>
  );
}

export default JobCard;
