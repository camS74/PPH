import React from 'react';
import '../styles/DesignSheet.css';

function DesignSheet() {
  return (
    <div className="designsheet-page">
      <h2>DesignSheet</h2>
      <p>This is the DesignSheet page. Content will be added later.</p>
    </div>
  );
}

export default DesignSheet;
